// ** React Imports
import { useState } from 'react'

// ** MUI Imports
import Paper from '@mui/material/Paper'
import Table from '@mui/material/Table'
import TableRow from '@mui/material/TableRow'
import TableHead from '@mui/material/TableHead'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TablePagination from '@mui/material/TablePagination'
import { Button, Icon } from '@mui/material'
import { Delete, Pencil, TrendingUp } from 'mdi-material-ui'


const columns = [
  { id: 'Nom', label: 'Nom', minWidth: 170 },
  { id: 'Prenom', label: 'Prenom', minWidth: 100 },
  {
    id: 'Email',
    label: 'Email',
    minWidth: 170,
    align: 'right',
  },
  {
    id: 'Mdp',
    label: 'Mot de passe',
    minWidth: 170,
    align: 'right',
  },
  {
    id: 'actions',
    label: 'Actions',
    minWidth: 200, // Ajustez la largeur en conséquence
    align: 'center',
    format: (value, index) => (
      <div>
        <Button
          variant="contained"
          size="small" 
          color="warning"
          onClick={() => handleEditButtonClick(index)}
          sx={{ marginRight: 2 }} 
        >
          <Pencil sx={{ fontSize: '1.5rem' }} />
        </Button>
        <Button
          variant="contained"
          size="small" 
          color="error"
          onClick={() => handleDeleteButtonClick(index)}
        >
          <Delete sx={{ fontSize: '1.5rem' }} />
        </Button>
      </div>
    ),
  },
]
const handleEditButtonClick = (index) => {
  console.log(`Bouton "Edit" cliqué pour la ligne ${index}`);
};

const handleDeleteButtonClick = (index) => {
  console.log(`Bouton "Delete" cliqué pour la ligne ${index}`);
};

function createData(Nom, Prenom, Email,Mdp,actions) {
  return { Nom, Prenom, Email, Mdp, actions }
}

const rows = [
  createData('India', 'IN','IN', 1324171354, 3287263),
  createData('China', 'CN','IN', 1403500365, 9596961),
  createData('Italy', 'IT','IN', 60483973, 301340),
  createData('United States','IN', 'US', 327167434, 9833520),
  createData('Canada', 'CA','IN', 37602103, 9984670),
  createData('Australia', 'AU','IN', 25475400, 7692024),
  createData('Germany', 'DE','IN', 83019200, 357578),
  createData('Ireland', 'IE','IN', 4857000, 70273),
  createData('Mexico', 'MX','IN', 126577691, 1972550),
  createData('Japan', 'JP','IN', 126317000, 377973),
  createData('France', 'FR','IN', 67022000, 640679),
  createData('United Kingdom', 'GB','IN', 67545757, 242495),
  createData('Russia', 'RU','IN', 146793744, 17098246),
  createData('Nigeria', 'NG','IN', 200962417, 923768),
  createData('Brazil', 'BR','IN', 210147125, 8515767)
]

const TableStickyHeader = () => {
  // ** States
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(10)
  
  
  const handleChangePage = (event, newPage) => {
    setPage(newPage)
  }

  const handleChangeRowsPerPage = event => {
    setRowsPerPage(+event.target.value)
    setPage(0)
  }

  return (
    <Paper sx={{ width: '100%', overflow: 'hidden' }}>
      <TableContainer sx={{ maxHeight: 600 }}>
        <Table stickyHeader aria-label='sticky table'>
          <TableHead>
            <TableRow>
              {columns.map(column => (
                <TableCell key={column.id} align={column.align} sx={{ minWidth: column.minWidth }}>
                  {column.label}
                </TableCell>
                
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map(row => {
              return (
                <TableRow hover role='checkbox' tabIndex={-1} key={row.code}>
                  {columns.map(column => {
                    const value = row[column.id]

                    return (
                      <TableCell key={column.id} align={column.align}>
                        {column.format && typeof value === 'number' ? column.format(value) : value}
                      </TableCell>
                    )
                  })}
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[10, 25, 100]}
        component='div'
        count={rows.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </Paper>
  )
}

export default TableStickyHeader
