> Install
```bash
# For npm
npm install --legacy-peer-deps

# For yarn
yarn install
```

> Run

```bash
# For npm
npm run dev

# For yarn
yarn dev
```